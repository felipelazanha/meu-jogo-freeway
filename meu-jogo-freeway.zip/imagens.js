//imagens do jogo
let imagemDaEstrada;
let imagemDoMushroom;
let imagemDoBanzai1;
let imagemDoBanzai2;
let imagemDoBanzai3;

//sons do jogo
let somDaTrilha;
let somDaColisao;
let somDoPonto;

function preload(){
  imagemDaEstrada = loadImage("imagens/estrada.png");
  imagemDoMushroom = loadImage("imagens/mushroom.png");
  imagemDoBanzai1 = loadImage("imagens/banzai1.png");
  imagemDoBanzai2 = loadImage("imagens/banzai2.png");
  imagemDoBanzai3 = loadImage("imagens/banzai3.png");
  imagemBanzais = [imagemDoBanzai2, imagemDoBanzai1, imagemDoBanzai2, imagemDoBanzai3, imagemDoBanzai2, imagemDoBanzai1];
  
  somDaTrilha = loadSound("sons/trilha.mp3");
  somDaColisao = loadSound("sons/colidiu.mp3");
  somDoPonto = loadSound("sons/pontos.wav");
  
  
  
  
}