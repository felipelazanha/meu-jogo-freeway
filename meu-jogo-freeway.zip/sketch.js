function setup() {
  createCanvas(600, 400);
  somDaTrilha.loop();
}

function draw() {
  background(imagemDaEstrada);
  mostraMushroom();
  mostraBanzai();
  movimentaBanzai();
  movimentaMushroom();
  voltaPosicaoInicialBanzai();
  verificaColisao();
  incluiPontos();
  marcaPonto();
}