//codigos do banzai

let xBanzais = [600, 600, 600, 600, 600, 600];
let yBanzais = [50, 100, 150, 200, 250, 300];
let velocidadeBanzais = [3.9, 6.9, 3.7, 6.7, 7.5, 3.5];
let comprimentoBanzai = 40;
let alturaBanzai = 40;

function mostraBanzai(){
  for (let i = 0; i < imagemBanzais.length; i++){
     image(imagemBanzais[i], xBanzais[i], yBanzais[i], comprimentoBanzai, alturaBanzai);
  }
}

function movimentaBanzai(){
  for (let i = 0; i < imagemBanzais.length; i++){
    xBanzais[i] -= velocidadeBanzais[i];
  }
}

function voltaPosicaoInicialBanzai(){
  for (let i = 0; i < imagemBanzais.length; i++){
    if (passouTodaATela(xBanzais[i])){
      xBanzais[i] = 600;
    }
  }
}

function passouTodaATela(xBanzais){
    return xBanzais < -50;
}