//codigos do mario

let xMushroom = 100;
let yMushroom = 365;
let colisao = false;
let meusPontos = 0;

function mostraMushroom(){
  image(imagemDoMushroom, xMushroom, yMushroom, 30, 30);
}

function movimentaMushroom(){
   if(keyIsDown(UP_ARROW)){
    yMushroom -= 3
 }
   if(keyIsDown(DOWN_ARROW)){
     if (podeSeMover()){
    yMushroom += 3
  }    
 }
   if(keyIsDown(LEFT_ARROW)){
    xMushroom -= 3
 }
   if(keyIsDown(RIGHT_ARROW)){
    xMushroom +=3
 }
}

function verificaColisao(){
  
  for (let i = 0; i < imagemBanzais.length; i++){
    colisao = collideRectCircle(xBanzais[i], yBanzais[i], comprimentoBanzai, alturaBanzai, (xMushroom+15), (yMushroom+15), 20) 
  if (colisao == true){
    voltaMushroomParaPosicaoInicial();
    somDaColisao.play();
    
     
     
    
    if (pontosMaiorQueZero()){
    meusPontos -= 1;
    }
   }
  }
}
function voltaMushroomParaPosicaoInicial(){
  yMushroom = 365;
}

function incluiPontos(){
  textAlign(CENTER)
  textSize(30)
  fill(color(0,0,139)) 
  text(meusPontos, width / 5, 30)
}

function marcaPonto(){
  if (yMushroom < 1){
    meusPontos += 1;
    somDoPonto.play();
    voltaMushroomParaPosicaoInicial();
  }
}

function pontosMaiorQueZero(){
  return meusPontos > 0
}

function podeSeMover(){
  return yMushroom < 365;
}